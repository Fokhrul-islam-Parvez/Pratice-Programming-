#include<stdio.h>
int main()
{
    int array_size;
    printf("Please Enter Array Size: ");
    scanf("%d",&array_size);
    int array[array_size];
    printf("Please Enter Array Element\n");
    int i,j=0;
    for(i=0;i<array_size;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Please Enter Search Number: ");
    int search_number;
    scanf("%d",&search_number);
    for(i=0;i<array_size;i++)
    {
        if(array[i]==array_size)
        {
            printf("Search number( %d ) is found\nIndex number = %d",search_number,i+1);
            j=1;
            break;
        }
    }
    if(j==0)
    {
         printf("Search number( %d ) is not found",search_number);
    }
    return 0;
}
